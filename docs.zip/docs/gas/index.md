---
title: "ГАС Правосудие — методы NEWDB"
description: "Обзор методов NEWDB для работы с данными ГАС Правосудие: поиск и детализация судебных дел, участники, события и документы."
canonical_url: https://newdb.net/docs/gas/
meta:
  - name: keywords
    content: "NEWDB API, ГАС Правосудие, суды общей юрисдикции, детали дела, судебные дела"
  - property: og:title
    content: "ГАС Правосудие — методы NEWDB"
  - property: og:description
    content: "Реестр методов NEWDB для работы с карточками судебных дел, событиями, участниками и документами из ГАС Правосудие."
---

# ГАС Правосудие

Раздел содержит методы NEWDB для работы с карточками судебных дел из ГАС Правосудие и связанных источников судов общей юрисдикции.

## Доступные методы

- [pravo_cases_details](01-pravo_cases_details.md) — детали судебного дела по `case_id` и `newdb_qid`
- [pravo_search](02-pravo_search.md) — поиск судебных дел по параметру `query`
- [act_text_search](03-act_text_search.md) — поиск судебных дел по текстам актов
